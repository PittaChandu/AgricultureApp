package com.example.agricultureapp

import android.app.Dialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.RatingBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat

class DashboardActivity : AppCompatActivity(), View.OnClickListener {

    private lateinit var cropInfoCard: CardView
    private lateinit var weatherCard: CardView
    private lateinit var marketPriceCard: CardView
    private lateinit var newsCard: CardView
    private lateinit var diseaseDetectionCard: CardView
    private lateinit var communityCard: CardView
    private lateinit var rateButton: Button
    private lateinit var sessionManager: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        // Initialize SessionManager
        sessionManager = SessionManager(this)

        // Check if user is logged in
        if (!sessionManager.isLoggedIn()) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }

        // Initialize UI components
        cropInfoCard = findViewById(R.id.card_crop_info)
        weatherCard = findViewById(R.id.card_weather)
        marketPriceCard = findViewById(R.id.card_market_price)
        newsCard = findViewById(R.id.card_news)
        diseaseDetectionCard = findViewById(R.id.card_disease_detection)
        communityCard = findViewById(R.id.card_community)
        rateButton = findViewById(R.id.btn_rate)

        // Set click listeners
        cropInfoCard.setOnClickListener(this)
        weatherCard.setOnClickListener(this)
        marketPriceCard.setOnClickListener(this)
        newsCard.setOnClickListener(this)
        diseaseDetectionCard.setOnClickListener(this)
        communityCard.setOnClickListener(this)
        rateButton.setOnClickListener(this)
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.card_crop_info -> {
                // Navigate to Crop Information Activity
                // startActivity(Intent(this, CropInfoActivity::class.java))
                showFeatureMessage("Crop Information")
            }
            R.id.card_weather -> {
                // Navigate to Weather Forecast Activity
                // startActivity(Intent(this, WeatherActivity::class.java))
                showFeatureMessage("Weather Forecast")
            }
            R.id.card_market_price -> {
                // Navigate to Market Price Activity
                // startActivity(Intent(this, MarketPriceActivity::class.java))
                showFeatureMessage("Market Prices")
            }
            R.id.card_news -> {
                // Navigate to Agricultural News Activity
                // startActivity(Intent(this, NewsActivity::class.java))
                showFeatureMessage("Agricultural News")
            }
            R.id.card_disease_detection -> {
                // Navigate to Disease Detection Activity
                // startActivity(Intent(this, DiseaseDetectionActivity::class.java))
                showFeatureMessage("Disease Detection")
            }
            R.id.card_community -> {
                // Navigate to Community Forum Activity
                // startActivity(Intent(this, CommunityActivity::class.java))
                showFeatureMessage("Community Forum")
            }
            R.id.btn_rate -> {
                showRatingDialog()
            }
        }
    }

    private fun showRatingDialog() {
        val dialog = Dialog(this)
        dialog.setContentView(R.layout.dialog_rating)
        dialog.setCancelable(true)

        val ratingBar = dialog.findViewById<RatingBar>(R.id.rating_bar)
        val submitButton = dialog.findViewById<Button>(R.id.btn_submit_rating)
        val cancelButton = dialog.findViewById<Button>(R.id.btn_cancel_rating)
        val ratingText = dialog.findViewById<TextView>(R.id.tv_rating_text)

        ratingBar.setOnRatingBarChangeListener { _, rating, _ ->
            when (rating.toInt()) {
                1 -> ratingText.text = "Poor"
                2 -> ratingText.text = "Below Average"
                3 -> ratingText.text = "Average"
                4 -> ratingText.text = "Good"
                5 -> ratingText.text = "Excellent"
                else -> ratingText.text = ""
            }
        }

        submitButton.setOnClickListener {
            val rating = ratingBar.rating
            // Save rating to database or send to server
            // For now, just show a toast
            Toast.makeText(
                this,
                "Thank you for rating us ${rating.toInt()} stars!",
                Toast.LENGTH_SHORT
            ).show()
            dialog.dismiss()
        }

        cancelButton.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun showFeatureMessage(featureName: String) {
        Toast.makeText(this, "$featureName feature selected", Toast.LENGTH_SHORT).show()
    }

    override fun onBackPressed() {
        // Show a confirmation dialog instead of immediately logging out
        val dialog = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Exit App")
            .setMessage("Do you want to log out and exit?")
            .setPositiveButton("Yes") { _, _ ->
                // User confirmed, log out
                sessionManager.logoutUser()
                super.onBackPressed()
            }
            .setNegativeButton("No", null)
            .create()

        dialog.show()
    }
}