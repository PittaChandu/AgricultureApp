package com.example.agricultureapp // Use your actual package name

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView // Added for the register link
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {

    // IDs from your activity_main.xml
    private lateinit var etEmail: EditText // Changed from etLoginUsername
    private lateinit var etPassword: EditText // Changed from etLoginPassword
    private lateinit var btnLogin: Button
    private lateinit var tvRegisterLink: TextView // Changed from tvGoToRegister

    // Optional: SessionManager
    // private lateinit var sessionManager: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) // Ensure this matches your file name


        // Initialize views using IDs from your XML
        etEmail = findViewById(R.id.etEmail) // Assumes TextInputEditText inside TextInputLayout
        etPassword = findViewById(R.id.etPassword) // Assumes TextInputEditText inside TextInputLayout
        btnLogin = findViewById(R.id.btnLogin)
        tvRegisterLink = findViewById(R.id.tvRegisterLink) // Initialize the register link TextView

        btnLogin.setOnClickListener {
            loginUser()
        }

        // Add click listener for the register link
        tvRegisterLink.setOnClickListener {
            // Navigate to RegisterActivity
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
        }
    }

    private fun loginUser() {
        // Use the correct variable names matching the initialized views
        val inputEmail = etEmail.text.toString().trim() // Changed from inputUsername
        val inputPassword = etPassword.text.toString().trim()

        if (inputEmail.isEmpty() || inputPassword.isEmpty()) {
            Toast.makeText(this, "Please enter email and password", Toast.LENGTH_SHORT).show()
            return
        }



        val sessionManager = SessionManager(this)
        if (sessionManager.validateLogin(inputEmail, inputPassword)) {
            // Login successful
            Toast.makeText(this, "Login Successful!", Toast.LENGTH_SHORT).show()
            sessionManager.createLoginSession(inputEmail)
            goToDashboard()
        } else {
            // Login failed
            Toast.makeText(this, "Invalid email or password", Toast.LENGTH_SHORT).show()
        }
    }

    private fun goToDashboard() {
        // Navigate to your main application screen (e.g., DashboardActivity)
        // Make sure DashboardActivity exists and is declared in your AndroidManifest.xml
        val intent = Intent(this, DashboardActivity::class.java)
        startActivity(intent)
        finish() // Close MainActivity so user can't navigate back to login
    }
}