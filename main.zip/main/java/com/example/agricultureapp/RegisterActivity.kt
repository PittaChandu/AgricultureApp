package com.example.agricultureapp // Use your actual package name

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView // Added for the login link
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class RegisterActivity : AppCompatActivity() {

    // IDs from your activity_register.xml
    private lateinit var etEmail: EditText // Changed from etRegisterUsername
    private lateinit var etPassword: EditText
    private lateinit var etConfirmPassword: EditText // Added for confirmation
    private lateinit var btnRegister: Button
    private lateinit var tvLoginLink: TextView // Added for navigation

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register) // Ensure this matches your file name

        // Initialize views using IDs from your XML
        etEmail = findViewById(R.id.etEmail) // Assumes TextInputEditText inside TextInputLayout
        etPassword = findViewById(R.id.etPassword) // Assumes TextInputEditText inside TextInputLayout
        etConfirmPassword = findViewById(R.id.etConfirmPassword) // Assumes TextInputEditText inside TextInputLayout
        btnRegister = findViewById(R.id.btnRegister)
        tvLoginLink = findViewById(R.id.tvLoginLink) // Initialize the login link TextView

        btnRegister.setOnClickListener {
            registerUser()
        }

        // Add click listener for the login link
        tvLoginLink.setOnClickListener {
            // Navigate back to MainActivity (Login Screen)
            val intent = Intent(this, MainActivity::class.java)
            // Optional: Clear task stack if you don't want user to go back to register via back button
            // intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            // finish() // Optional: finish RegisterActivity if you navigated clear task
        }
    }

    private fun registerUser() {
        // Use the correct variable names matching the initialized views
        val email = etEmail.text.toString().trim() // Changed from username
        val password = etPassword.text.toString().trim()
        val confirmPassword = etConfirmPassword.text.toString().trim() // Get confirm password text

        // Basic validation
        if (email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            return
        }

        // More specific validation (e.g., email format) can be added here

        // Check if passwords match
        if (password != confirmPassword) {
            Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show()
            // Optionally set an error on the confirm password field
            etConfirmPassword.error = "Passwords do not match"
            return
        } else {
            // Clear error if passwords match now
            etConfirmPassword.error = null
        }



        val sessionManager = SessionManager(this)
        sessionManager.registerUser(email, password)


        Toast.makeText(this, "Registration Successful!", Toast.LENGTH_SHORT).show()

        // Navigate back to Login activity automatically after registration
        val intent = Intent(this, MainActivity::class.java)
        // Optional: Flags to clear the back stack
        // intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish() // Close RegisterActivity after successful registration
    }
}