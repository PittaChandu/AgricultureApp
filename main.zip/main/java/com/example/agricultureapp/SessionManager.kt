package com.example.agricultureapp

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences

/**
 * Session Manager for handling user sessions
 * - Stores login status and user credentials using SharedPreferences
 * - Provides methods for login, logout, and checking login status
 */
class SessionManager(private val context: Context) {
    // Shared Preferences
    private var pref: SharedPreferences
    private var editor: SharedPreferences.Editor
    private val PREF_NAME = "UserPrefs"

    // Shared pref mode
    private val PRIVATE_MODE = 0

    // Shared preferences keys
    private val IS_LOGIN = "IsLoggedIn"
    private val KEY_EMAIL = "registered_email"
    private val KEY_PASSWORD = "registered_password"

    init {
        pref = context.getSharedPreferences(PREF_NAME, PRIVATE_MODE)
        editor = pref.edit()
    }

    /**
     * Creates login session using the user's email
     */
    fun createLoginSession(email: String) {
        // Store login value as TRUE
        editor.putBoolean(IS_LOGIN, true)

        // Store email in pref for future reference (optional)
        editor.putString(KEY_EMAIL, email)

        // Commit changes
        editor.apply()
    }

    /**
     * Check login status
     * If false, redirect to Login Activity
     */
    fun isLoggedIn(): Boolean {
        return pref.getBoolean(IS_LOGIN, false)
    }

    /**
     * Get stored credentials
     * This method gives you the stored credentials
     * @return HashMap with user data
     */
    fun getUserDetails(): HashMap<String, String?> {
        val user = HashMap<String, String?>()
        user[KEY_EMAIL] = pref.getString(KEY_EMAIL, null)
        user[KEY_PASSWORD] = pref.getString(KEY_PASSWORD, null)
        return user
    }

    /**
     * Clear session details and redirect to LoginActivity
     */
    fun logoutUser() {
        // Only clear login status, not the registered credentials
        editor.putBoolean(IS_LOGIN, false)
        editor.apply()

        // Redirect to Login Activity after logout
        val intent = Intent(context, MainActivity::class.java)
        // Close all activities on top
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        context.startActivity(intent)
    }

    /**
     * Register a new user
     * - Stores credentials and marks as logged in
     */
    fun registerUser(email: String, password: String) {
        // Store credentials
        editor.putString(KEY_EMAIL, email)
        editor.putString(KEY_PASSWORD, password)

        // Mark as logged in
        editor.putBoolean(IS_LOGIN, true)

        // Commit changes
        editor.apply()
    }

    /**
     * Validate login credentials
     * @return true if valid, false otherwise
     */
    fun validateLogin(email: String, password: String): Boolean {
        val storedEmail = pref.getString(KEY_EMAIL, null)
        val storedPassword = pref.getString(KEY_PASSWORD, null)

        return email == storedEmail && password == storedPassword
    }
}