package com.example.agricultureapp // Use your actual package name

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
// Import R explicitly if needed
// import com.example.agricultureapp.R

class SplashActivity : AppCompatActivity() {

    // Duration of wait in milliseconds
    private val SPLASH_DISPLAY_LENGTH: Long = 3000 // 3 seconds

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        // Use a Handler to delay the start of MainActivity
        Handler(Looper.getMainLooper()).postDelayed({
            // Create an Intent that will start the MainActivity.
            val mainIntent = Intent(this@SplashActivity, MainActivity::class.java)
            startActivity(mainIntent)

            // Close this activity
            finish()
        }, SPLASH_DISPLAY_LENGTH)
    }
}